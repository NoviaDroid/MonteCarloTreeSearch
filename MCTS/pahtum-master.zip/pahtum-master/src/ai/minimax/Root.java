package ai.minimax;

public class Root {
	private MMNode root;
	
	public Root(MMNode node) {
		this.root = node;
	}
	
	public MMNode getRoot() {
		return this.root;
	}
}
