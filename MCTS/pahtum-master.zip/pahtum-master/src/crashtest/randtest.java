package crashtest;

import java.util.Random;

public class randtest {
	public static void main(String[] args) {
		Random r = new Random();
		
		System.out.println(r.nextInt(0));
	}
}
