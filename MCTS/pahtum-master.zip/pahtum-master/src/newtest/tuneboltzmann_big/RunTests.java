package newtest.tuneboltzmann_big;

public class RunTests {

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		GigaTest1.main(null);
		GigaTest2.main(null);
		GigaTest3.main(null);
		GigaTest4.main(null);
	}

}
