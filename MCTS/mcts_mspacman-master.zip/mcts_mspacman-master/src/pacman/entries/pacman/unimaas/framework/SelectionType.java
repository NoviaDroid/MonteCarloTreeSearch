package pacman.entries.pacman.unimaas.framework;

/**
 *
 * @author Tom Pepels, Maastricht University
 */
public enum SelectionType {
    SurvivalRate, GhostScore, PillScore, Distance;
}
