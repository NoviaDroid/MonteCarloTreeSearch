package pacman.entries.pacman.unimaas.framework;

import pacman.game.Constants.MOVE;

public interface PacManMoveGenerator {
	public MOVE generatePacManMove();
}
