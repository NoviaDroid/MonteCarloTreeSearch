package itu.ejuuragr;

public interface MCTSNode {
	
	public MCTSNode expand();
	public boolean isExpanded();
}
