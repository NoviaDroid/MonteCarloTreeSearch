__author__="Sergey Karakovskiy, sergey at idsia fullstop ch"
__date__ ="$May 13, 2009 12:15:26 AM$"

from mariotask import MarioTask

